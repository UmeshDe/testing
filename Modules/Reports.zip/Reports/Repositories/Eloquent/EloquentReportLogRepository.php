<?php

namespace Modules\Reports\Repositories\Eloquent;

use Modules\Reports\Repositories\ReportLogRepository;
use Modules\Core\Repositories\Eloquent\EloquentBaseRepository;

class EloquentReportLogRepository extends EloquentBaseRepository implements ReportLogRepository
{
}

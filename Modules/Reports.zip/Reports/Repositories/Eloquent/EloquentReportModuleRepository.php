<?php

namespace Modules\Reports\Repositories\Eloquent;

use Modules\Reports\Repositories\ReportModuleRepository;
use Modules\Core\Repositories\Eloquent\EloquentBaseRepository;

class EloquentReportModuleRepository extends EloquentBaseRepository implements ReportModuleRepository
{
}

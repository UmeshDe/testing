<?php

namespace Modules\Reports\Repositories\Eloquent;

use Modules\Reports\Repositories\ReportParameterRepository;
use Modules\Core\Repositories\Eloquent\EloquentBaseRepository;

class EloquentReportParameterRepository extends EloquentBaseRepository implements ReportParameterRepository
{
}

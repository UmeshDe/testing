<?php

namespace Modules\Reports\Repositories;

use Modules\Core\Repositories\BaseRepository;

interface ReportMasterRepository extends BaseRepository
{
}

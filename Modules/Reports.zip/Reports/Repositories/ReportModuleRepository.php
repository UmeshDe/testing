<?php

namespace Modules\Reports\Repositories;

use Modules\Core\Repositories\BaseRepository;

interface ReportModuleRepository extends BaseRepository
{
}

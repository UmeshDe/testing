<?php

namespace Modules\Reports\Repositories;

use Modules\Core\Repositories\BaseRepository;

interface ReportParameterRepository extends BaseRepository
{
}

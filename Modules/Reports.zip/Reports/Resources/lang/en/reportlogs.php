<?php

return [
    'list resource' => 'List reportlogs',
    'create resource' => 'Create reportlogs',
    'edit resource' => 'Edit reportlogs',
    'destroy resource' => 'Destroy reportlogs',
    'generate report'=>'Generate Rerport',
    'title' => [
        'reportlogs' => 'ReportLog',
        'create reportlog' => 'Create a reportlog',
        'edit reportlog' => 'Edit a reportlog',
    ],
    'button' => [
        'create reportlog' => 'Create a reportlog',
    ],
    'table' => [
    ],
    'form' => [
    ],
    'messages' => [
    ],
    'validation' => [
    ],
];

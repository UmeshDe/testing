<?php

return [
    'list resource' => 'List reportmasters',
    'create resource' => 'Create reportmasters',
    'edit resource' => 'Edit reportmasters',
    'destroy resource' => 'Destroy reportmasters',
    'title' => [
        'name' => 'Reports',
        'reportmasters' => 'ReportMaster',
        'create reportmaster' => 'Create a reportmaster',
        'edit reportmaster' => 'Edit a reportmaster',
    ],
    'button' => [
        'create reportmaster' => 'Create a reportmaster',
    ],
    'table' => [
    ],
    'form' => [
    ],
    'messages' => [
    ],
    'validation' => [
    ],
];

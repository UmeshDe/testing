<?php

return [
    'list resource' => 'List reportmodules',
    'create resource' => 'Create reportmodules',
    'edit resource' => 'Edit reportmodules',
    'destroy resource' => 'Destroy reportmodules',
    'title' => [
        'reportmodules' => 'ReportModule',
        'create reportmodule' => 'Create a reportmodule',
        'edit reportmodule' => 'Edit a reportmodule',
    ],
    'button' => [
        'create reportmodule' => 'Create a reportmodule',
    ],
    'table' => [
    ],
    'form' => [
    ],
    'messages' => [
    ],
    'validation' => [
    ],
];

<?php

return [
    'list resource' => 'List reportparameters',
    'create resource' => 'Create reportparameters',
    'edit resource' => 'Edit reportparameters',
    'destroy resource' => 'Destroy reportparameters',
    'title' => [
        'reportparameters' => 'ReportParameter',
        'create reportparameter' => 'Create a reportparameter',
        'edit reportparameter' => 'Edit a reportparameter',
    ],
    'button' => [
        'create reportparameter' => 'Create a reportparameter',
    ],
    'table' => [
    ],
    'form' => [
    ],
    'messages' => [
    ],
    'validation' => [
    ],
];

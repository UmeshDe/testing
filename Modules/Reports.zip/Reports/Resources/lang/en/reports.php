<?php

return [
    'list resource' => 'List Reports',
    'create resource' => 'Create Report',
    'edit resource' => 'Edit Report',
    'destroy resource' => 'Destroy Report',
    'title' => [
        'name' => 'Reports Admin',
        'create approvalnumber' => 'Create a Report',
        'edit approvalnumber' => 'Edit',
        'report list' => 'Reports'
    ],
    'button' => [
        'create approvalnumber' => 'Create a Report',
    ],
    'table' => [
    ],
    'form' => [
    ],
    'messages' => [
    ],
    'validation' => [
    ],
];

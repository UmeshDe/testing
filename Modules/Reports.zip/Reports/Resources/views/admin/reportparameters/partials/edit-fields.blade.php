<div class="box-body">
    <p>
        Your fields //
    </p>
</div>

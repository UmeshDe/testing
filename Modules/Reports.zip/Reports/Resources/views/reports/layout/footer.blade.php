<div class="report-subfooter" style="{{$report->reportMaster->sub_footer_style}}">
    {{$report->reportMaster->sub_footer}}
</div>
<div  class="report-footer" style="{{$report->reportMaster->footer_style}}">
    {{$report->reportMaster->footer}}
</div>
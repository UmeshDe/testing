<div class="report-title" style="{{$report->reportMaster->title_style}}">
    ULKA SAEFOODS PVT .LTD.<br>
    {{--{{$report->reportMaster->title}}--}}
</div>
<div class="report-subtitle" style="{{$report->reportMaster->sub_title_style}}">
{{--    {{$report->reportMaster->sub_title}}--}}
</div>